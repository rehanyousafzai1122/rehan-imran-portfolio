import { motion, type Variants } from "motion/react";
import type { ElementType, ReactNode } from "react";
import clsx from "clsx";

interface ScrollBlurTextProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  staggerChildren?: boolean;
  staggerDelay?: number;
  as?: ElementType;
}

/**
 * ScrollBlurText — Text starts blurred and sharpens as it scrolls into view.
 *
 * - Blur (20px → 0px) + opacity (0 → 1), duration 800ms by default
 * - Scroll-triggered via viewport detection (fires once)
 * - Optional per-child stagger for a cascading effect
 *
 * Usage:
 * <ScrollBlurText as="h2" className="text-3xl font-bold">
 *   This text sharpens on scroll
 * </ScrollBlurText>
 */
export function ScrollBlurText({
  children,
  className,
  delay = 0,
  duration = 0.8,
  staggerChildren = false,
  staggerDelay = 0.05,
  as = "div",
}: ScrollBlurTextProps) {
  const MotionTag = motion.create(as);

  const variants: Variants = {
    hidden: { filter: "blur(20px)", opacity: 0 },
    visible: (i: number) => ({
      filter: "blur(0px)",
      opacity: 1,
      transition: {
        duration,
        delay: delay + (staggerChildren ? i * staggerDelay : 0),
        ease: [0.22, 1, 0.36, 1],
      },
    }),
  };

  if (staggerChildren && Array.isArray(children)) {
    return (
      <MotionTag className={clsx("will-change-[filter,opacity]", className)}>
        {children.map((child, i) => (
          <motion.span
            key={i}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={variants}
            custom={i}
            className="inline-block"
          >
            {child}
          </motion.span>
        ))}
      </MotionTag>
    );
  }

  return (
    <MotionTag
      className={clsx("will-change-[filter,opacity]", className)}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.5 }}
      variants={variants}
    >
      {children}
    </MotionTag>
  );
}

export default ScrollBlurText;
